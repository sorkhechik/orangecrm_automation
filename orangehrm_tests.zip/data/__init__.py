# pages/__init__.py
# This file makes the pages directory a Python package
